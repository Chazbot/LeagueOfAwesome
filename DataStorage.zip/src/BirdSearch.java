//Albert Lee
//10/21/2012
//BirdSearch.java
// How to store birds and search for birds
// Don't know how to use SQL, so used text file as dummy
//
// * -Will read birds from text file ( line by line ) 
//   -Put them into a Vector
//   -Sort them
//   -User able to search for bird by name

import java.util.Scanner; //System.in
import java.util.Vector; //vector<string>
import java.util.Collections; //sort, binary search

public class BirdSearch 
{
	public static void main( String[] args ) 
	{
		int birdIndex; //index of bird searched
		
		//type in file name
		System.out.println( "Enter text file name without file extension" );
		
		//user input
		Scanner keyboard = new Scanner ( System.in );
		
		//file input stream
		Scanner dataReader = null;
		
		//will hold bird data
		Vector<String> birdData = new Vector<String>();
		
		//to read data
		FileInput newInputFile = new FileInput();
		dataReader = newInputFile.readData( keyboard.next() );
		
		
		//check EOF
		while( dataReader.hasNextLine() )
		{
			//add each line read to vector
			birdData.add( dataReader.nextLine() );
		}
		
		
		//sort data in alphabetic order using Collections.sort <- Java library
		Collections.sort(birdData);
		
		//make sure birds are sorted //test purposes
		for(int i = 0; i < birdData.size(); i++ )
		{
			System.out.println(birdData.elementAt(i));
		}
		
		
		//ask user for bird name - input
		System.out.println( " Enter Bird Name to Search for in Database: ");
		
		//binary search provided by Collections.binarySearch <- Java library
		birdIndex = Collections.binarySearch( birdData, keyboard.next());
		
		//binary search returns negative value if not found
		if( birdIndex < 0 )
		{
			System.out.println( "Bird not Found" );
		}
		else 
		{
			System.out.println( "Bird found at index: " + birdIndex );
		}
		
	}

}
